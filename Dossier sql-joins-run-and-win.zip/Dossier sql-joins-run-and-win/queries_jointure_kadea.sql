
-- SELECT * FROM categories;
-- SELECT * FROM clients;
-- SELECT * FROM magasins;
-- SELECT * FROM produits;
-- SELECT * FROM ventes;
-- SELECT * FROM villes;

/**
1. Le Rapport Lisible (La fin du RECHERCHEV)

"Je veux la liste de toutes les ventes, mais remplace 
les IDs par le nom du produit et le nom de la ville du magasin. 
Affiche aussi la date et la quantité."
**/
SELECT 
	v.quantite_vendue AS quantité_vendue, 
	v.date_vente AS date_vente, 
	p.nom_produit AS nom_produits, 
	m.nom_magasin AS nom_du_magasin, 
	vil.nom_ville AS nom_de_la_ville_du_magasin
FROM ventes AS v
INNER JOIN produits AS p
	ON v.id_produit = p.id_produit
INNER JOIN magasins AS m
	ON v.id_magasin = m.id_magasin
INNER JOIN villes AS vil
	ON m.id_ville = vil.id_ville
ORDER BY v.date_vente DESC;

/**
2. Le focus "Grand Kivu"

"On veut analyser les performances à l'Est. 
Donne-moi toutes les ventes (Nom produit, Prix, Quantité) 
réalisées uniquement dans les magasins de Goma et Bukavu."
**/

SELECT 
	v.quantite_vendue,
    v.date_vente,
    p.prix,
    p.nom_produit,
    m.nom_magasin, 
    vil.nom_ville
FROM ventes AS v
INNER JOIN produits AS p
	ON v.id_vente = p.id_produit
INNER JOIN magasins AS m
	ON v.id_magasin = m.id_magasin
INNER JOIN villes AS vil
	ON m.id_ville = vil.id_ville
WHERE vil.nom_ville IN ('Goma', 'Bukavu');



/**
3. Le top "Katanga"

"À Lubumbashi, quels sont les produits de la catégorie 'Running' que nous avons vendus ? 
Je veux le nom des produits et le total des quantités vendues."
**/

SELECT 
    p.nom_produit,
    SUM(v.quantite_vendue) AS total_qte_vendues
FROM ventes AS v
INNER JOIN produits AS p 
	ON v.id_produit = p.id_produit
INNER JOIN categories AS c
	ON p.id_categorie = c.id_categorie
INNER JOIN magasins AS m 
	ON v.id_magasin = m.id_magasin
INNER JOIN villes AS vil
	ON m.id_ville = vil.id_ville
WHERE vil.nom_ville = 'Lubumbashi'
	AND c.nom_categorie = 'Running'
GROUP BY p.nom_produit
ORDER BY total_qte_vendues DESC;
    
    
/**
4. La rentabilité par Magasin

"Mr Jhon veut savoir quel magasin a généré le plus de cash. 
Affiche le Nom du magasin, sa Ville et le Chiffre d'Affaires total."
**/
SELECT 
	m.nom_magasin, 
    vil.nom_ville,
    SUM(v.quantite_vendue * p.prix) AS chiffre_affaire_total
FROM ventes AS v 
INNER JOIN produits AS p 
	ON v.id_produit = p.id_produit
INNER JOIN magasins AS m 
	ON v.id_magasin = m.id_magasin
INNER JOIN villes AS vil
	ON m.id_ville = vil.id_ville
GROUP BY m.nom_magasin, vil.nom_ville
ORDER BY chiffre_affaire_total DESC;



/**
5. L'inventaire des catégories par Ville

"Est-ce qu'on vend du 'Yoga' à Matadi ? 
Liste les noms des catégories vendues par ville, sans doublons."

**/

SELECT
	DISTINCT
	vil.nom_ville,
	c.nom_categorie
FROM ventes AS v
INNER JOIN produits AS p
	ON v.id_produit = p.id_produit
INNER JOIN categories AS c
	ON p.id_categorie = c.id_categorie
INNER JOIN magasins AS m
	ON v.id_magasin = m.id_magasin
INNER JOIN villes AS vil
	ON m.id_ville = vil.id_ville
    
